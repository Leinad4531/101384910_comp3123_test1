function lowerCaseWords(arrays) {
    return new Promise((resolve, reject) => {
        if (!Array.isArray(arrays)) {
            reject(new Error('Input is not an array'));
        } else {
            const filteredWords = arrays.filter(item => typeof item === 'string');
            const lowerCasedWords = filteredWords.map(word => word.toLowerCase());
            resolve(lowerCasedWords);
        }
    });
}

//Input
const mixedArray = ["PIZZA", 10, true, 25, false, "Wings"];
lowerCaseWords(mixedArray)
    .then(data => {
        console.log('Lowercased Words:', data);
    })
    .catch(error => {
        console.error('Error:', error.message);
    });