function resolvedPromise() {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve({ message: 'delayed success' });
        }, 500);
    });
}

function rejectedPromise() {
    return new Promise((reject) => {
        setTimeout(() => {
            reject({error: 'delayed exception!'})
        }, 500);
    });
}

// Calling resolvedPromise and handling the result
resolvedPromise()
    .then(data => {
        console.log(data);
    })
    .catch(error => {
        console.error("Resolved Promise Error:", error.message);
    });

// Calling rejectedPromise and handling the result
rejectedPromise()
    .then(data => {
        console.log(data);
    })
    .catch(error => {
        console.error("Rejected Promise Error:", error.message);
    });
