const fs = require('fs');
const path = require('path');

const logsDirectory = path.join(__dirname, 'Logs');

// Check if the Logs directory exists
if (fs.existsSync(logsDirectory)) {
    // Get a list of all files in the Logs directory
    const filesToDelete = fs.readdirSync(logsDirectory);

    // Remove all the files from the Logs directory
    filesToDelete.forEach((file) => {
        const filePath = path.join(logsDirectory, file);
        fs.unlinkSync(filePath);
        console.log("deleted file..." + file);

    });

    // Remove the Logs directory
    fs.rmdirSync(logsDirectory);

} else {
    console.log("Logs directory does not exist.");
}
