const fs = require('fs');
const path = require('path');

const logsDirectory = path.join(__dirname, 'Logs');

// Create Logs directory if it does not exist
if (!fs.existsSync(logsDirectory)) {
    fs.mkdirSync(logsDirectory);
    // Change the current process to the new Logs directory
    process.chdir(logsDirectory);

    // Create 10 log files and write some text into the file
    for (let i = 0; i <= 9; i++) {
        const fileName = `log${i}.txt`;
        const filePath = path.join(logsDirectory, fileName);
        const logText = `This is log file number ${i}`;

        fs.writeFileSync(filePath, logText);

        console.log(fileName);
    }
}else{
    console.log("The log folder already exists.");
}



